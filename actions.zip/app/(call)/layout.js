export default function CallLayout({ children }) {
  return <>{children}</>;
}